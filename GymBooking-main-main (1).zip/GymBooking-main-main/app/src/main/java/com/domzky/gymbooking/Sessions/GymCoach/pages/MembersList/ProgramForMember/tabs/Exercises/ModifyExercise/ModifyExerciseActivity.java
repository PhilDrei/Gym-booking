package com.domzky.gymbooking.Sessions.GymCoach.pages.MembersList.ProgramForMember.tabs.Exercises.ModifyExercise;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.domzky.gymbooking.R;

public class ModifyExerciseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coach_exercise_form_to_member);



    }
}
