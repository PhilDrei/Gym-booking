package com.domzky.gymbooking.Helpers.Users;

public class Admin {

    public String fullname,email,phone,username,password;

    public Admin() {

    }

    public Admin(String fullname,String email,String phone,String username,String password) {
        this.fullname = fullname;
        this.email = email;
        this.phone = phone;
        this.username = username;
        this.password = password;
    }

}
