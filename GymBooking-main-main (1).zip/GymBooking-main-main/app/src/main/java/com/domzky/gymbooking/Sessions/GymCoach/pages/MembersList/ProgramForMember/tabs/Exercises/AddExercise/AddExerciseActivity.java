package com.domzky.gymbooking.Sessions.GymCoach.pages.MembersList.ProgramForMember.tabs.Exercises.AddExercise;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.domzky.gymbooking.R;

public class AddExerciseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coach_exercise_form_to_member);



    }
}